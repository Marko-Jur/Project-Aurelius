//Pin Assignments

#ifndef _PINASSIGNMENTS_H    
#define _PINASSIGNMENTS_H

//Potentiometer Pins
#define AXIS_1_POT A0

//Axis 1 pins:
#define STEP_PIN 6 //PUL -Pulse
#define DIR_PIN 7 //DIR -Direction
#define EN_PIN 8 //ENA -Enable

#endif
