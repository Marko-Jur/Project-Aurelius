#import <Arduino.h> 
#include "Pin_Assignments.h"
#include "Globals.h"
#include "Libraries.h"



//Variables for input processing
//Pot raws
int axis_1_pot_raw = 0;


//Mapped step inputs
int axis_1_step = 0;

//Filter variables:
int EMA_SAMPLE_1 = 0;




/* Function Name:Input setup
 * Date Edited: 21st June 2021
 * 
 * Inputs: None
 * Outputs: None
 * Resources: None
 *
 * Description: Sets up the toggle switches and potentiometers
 */
void inputSetup(){

  pinMode(AXIS_1_POT,INPUT);
  
  EMA_SAMPLE_1 = analogRead(AXIS_1_POT);
  
}

/* Function Name:Input read
 * Date Edited: 21st June 2021
 * 
 * Inputs: None
 * Outputs: None
 * Resources: None
 *
 * Description: Reads the toggle switches and potentiometers and stores the values in the control array
 */
int potReader(){

  //Reading pot inputs
  axis_1_pot_raw = analogRead(AXIS_1_POT);
  
  //Filtering Pot Values - a 100uF capacitor must be added in parallel with the pot
  //Filtering axis 1 pot samples
  EMA_SAMPLE_1 = float((EMA_ALPHA*axis_1_pot_raw) +((1-EMA_ALPHA)*EMA_SAMPLE_1));

  axis_1_step = map(EMA_SAMPLE_1,POT_MIN,POT_MAX,AXIS_1_RANGE_MIN,AXIS_1_RANGE_MAX);

  Serial.println(EMA_SAMPLE_1);
  
  delay(1);
  
  return axis_1_step;

}
