//Pin Assignments

#ifndef MANUAL_MODE_READING_H   
#define MANUAL_MODE_READING_H

void inputSetup();
int potReader();

#endif
