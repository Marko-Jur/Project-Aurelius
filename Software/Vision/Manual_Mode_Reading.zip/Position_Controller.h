//Pin Assignments

#ifndef POSITION_CONTROLLER_H   
#define POSITION_CONTROLLER_H

void motorSetup();


void axisOneController(int control_val);

#endif
