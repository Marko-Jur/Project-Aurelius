#import <Arduino.h> 
#include "Pin_Assignments.h"
#include "Globals.h"
#include "Libraries.h"


//Variables:
int previous_val = 0;
int position_update = 0;




void motorSetup(){
  pinMode(STEP_PIN,OUTPUT); 
  pinMode(DIR_PIN,OUTPUT);
  pinMode(EN_PIN,OUTPUT);

  digitalWrite(DIR_PIN,HIGH);
  
}

void axisOneController(int control_val){


  position_update = control_val - previous_val;
  

  //if (position_update > 0){
    
    //  digitalWrite(DIR_PIN,HIGH);
 // }

 // else{

     // digitalWrite(DIR_PIN,LOW);
      
 // }
/*
   if (abs(position_update) > DEADZONE){
    for(int x = 0; x < abs(position_update * AXIS_1_GEAR_RATIO); x++){
          digitalWrite(STEP_PIN,HIGH); 
          delayMicroseconds(500); 
          digitalWrite(STEP_PIN,LOW); 
          delayMicroseconds(500); 
    }
   }
  
  previous_val = control_val;
 */

    for(int x = 0; x < 500; x++){
          digitalWrite(STEP_PIN,HIGH); 
          delayMicroseconds(500); 
          digitalWrite(STEP_PIN,LOW); 
          delayMicroseconds(500); 
          Serial.println("testtt");
    }

  
}
